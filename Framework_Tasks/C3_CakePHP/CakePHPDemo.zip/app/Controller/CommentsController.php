<?php
class CommentsController extends AppController {
	function create() {
		$pid = $this->request->query('pid');
		$id = $this->Auth->user('id');

		$this->request->data['Comment']['userid'] = $id;
		$this->request->data['Comment']['postid'] = $pid;
		$this->Comment->create();
		$this->Comment->save($this->request->data);
		return $this->redirect(array(
			'controller' => 'posts',
			'action' => "read?pid=$pid"
			));
	}

	function delete() {
		$id = $this->Auth->user('id');
		$cid = $this->request->query['cid'];

		$comment = $this->Comment->findById($cid);
		if($comment['Comment']['userid'] == $id)
			$this->Comment->delete($cid);

		$pid = $comment['Comment']['postid'];
		return $this->redirect(array(
			'controller' => 'posts',
			'action' => "read?pid=$pid"
			));
	}

	function edit() {
		$id = $this->Auth->user('id');
		$cid = $this->request->query['cid'];

		$comment = $this->Comment->findById($cid);
		if($comment['Comment']['userid'] == $id) {
			$value = $this->Comment->getDataSource()->value($this->request->data['Comment']['comment'], 'string');
			$this->Comment->updateAll(
					array('Comment.comment' => $value),
					array('Comment.id' => $cid)
				);
		}

		$pid = $comment['Comment']['postid'];
		return $this->redirect(array(
			'controller' => 'posts',
			'action' => "read?pid=$pid"
			));
	}

	function editF() {
		$id = $this->request->query('cid');
		$this->set(array(
			'id' => $id,
			'value' => $this->Comment->findById($id)['Comment']['comment']));
	}
}
?>