<?php
class PostsController extends AppController {
	function index() {
		$id = $this->Auth->user('id');
		$this->loadModel('Editor');
		$this->loadModel('Admin');
		$canCreatePost = $this->Editor->isEditor($id) || $this->Admin->isAdmin($id);
		$this->set('showForm', $canCreatePost);

		$this->paginate = array(
			'limit' => 10,
			'order' => array('Post.id' => 'desc'));
		$data = $this->paginate();
		$this->set('posts', $data);
	}

	function create() {
		$id = $this->Auth->user('id');
		$this->loadModel('Editor');
		$this->loadModel('Admin');
		$canCreatePost = $this->Editor->isEditor($id) || $this->Admin->isAdmin($id);
		if($canCreatePost && $this->request->is('post')) {
			$this->Post->create();
			$this->request->data['Post']['userid'] = $id;
			$this->Post->save($this->request->data);
		}
		return $this->redirect(array('action' => 'index'));
	}

	function delete() {
		$id = $this->Auth->user('id');
		$pid = $this->request->query['pid'];

		$canDeletePost = $this->Post->isOwner($id, $pid);
		if($canDeletePost) {
			$this->Post->delete($pid);
		}

		return $this->redirect(array('action' => "index"));
	}

	function edit() {
		$id = $this->Auth->user('id');
		$pid = $this->request->query['pid'];
		
		$canEditPost = $this->Post->isOwner($id, $pid);
		if($canEditPost) {
			$value = $this->Post->getDataSource()->value($this->request->data['Post']['content'], 'string');
			$this->Post->updateAll(
					array('Post.content' => $value),
					array('Post.id' => $pid)
				);
		}

		return $this->redirect(array('action' => "read?pid=$pid"));
	}

	function editF() {
		$id = $this->request->query('pid');
		$this->set(array(
			'id' => $id,
			'value' => $this->Post->findById($id)['Post']['content']));
	}

	function read() {
		$id = $this->Auth->user('id');
		$pid = $this->request->query['pid'];
		$data = $this->Post->findById($pid);

		$this->loadModel('Comment');
		foreach($data['Comment'] as $key => $value) {
			$data['Comment'][$key] = $this->Comment->findById($value['id']);
			$data['Comment'][$key]['modifiable'] = $data['Comment'][$key]['Comment']['userid'] == $id;
		}

		$this->set('canModify', $data['Post']['userid'] == $id);
		$this->set('post', $data);
	}

}
?>