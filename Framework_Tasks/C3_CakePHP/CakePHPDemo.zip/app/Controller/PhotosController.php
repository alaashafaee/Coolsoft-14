<?php
App::uses('AppController', 'Controller');
/**
 * Photos Controller
 *
 * @property Photo $Photo
 * @property PaginatorComponent $Paginator
 */
class PhotosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

	function index() {
		$this->paginate = array(
			'order' => array('Photo.id' => 'desc'));
		$data = $this->paginate();
		$this->set('photos', $data);
	}

	function admin_index() {
		$id = $this->Auth->user('id');
		$this->loadModel('Admin');
		if(!$this->Admin->isAdmin($id))
			throw new NotFoundException('404 Error - Page not found');

		$this->paginate = array(
			'order' => array('Photo.id' => 'desc'));
		$data = $this->paginate();
		$this->set('photos', $data);
	}

	function admin_delete() {
		$id = $this->Auth->user('id');
		$this->loadModel('Admin');
		if(!$this->Admin->isAdmin($id))
			throw new NotFoundException('404 Error - Page not found');

		$pid = $this->request->query('pid');

		$this->Photo->delete($pid);
		return $this->redirect(array('action' => 'index'));
	}

	function admin_create() {
		$id = $this->Auth->user('id');
		$this->loadModel('Admin');
		if(!$this->Admin->isAdmin($id))
			throw new NotFoundException('404 Error - Page not found');

		$this->Photo->create();
		$this->Photo->save($this->request->data);

		return $this->redirect(array('action' => 'index'));
	}
}
