<?php
App::uses('AppController', 'Controller');
/**
 * Users Controller
 *
 * @property User $User
 * @property PaginatorComponent $Paginator
 */
class UsersController extends AppController {
	public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('index', 'login', 'register');
    }

	function index() {

	}

	function login() {
	    if ($this->request->is('post')) {
	        if ($this->Auth->login()) {
	            return $this->redirect($this->Auth->redirect());
	        }
	        $this->Session->setFlash(__('Invalid username or password, try again'));
	    } 
	    return $this->redirect(array('action' => 'index'));
	}

	function register() {
		if ($this->request->is('post')) {
            $this->User->create();
            $newRecord = array(
            		'User.username' =>
            			$this->request->data['User']['username']
            	);

            if($this->User->hasAny($newRecord)) {
	            $this->Session->setFlash(
	                __('That username is in use. Please, try another.')
	            );
            } else if ($this->User->save($this->request->data)) {
                $this->Session->setFlash(__('You have registered.'));
            } else {
	            $this->Session->setFlash(
	                __('Registration error. Please, try again.')
	            );
            }
        }
        return $this->redirect(array('action' => 'index'));
	}

	function logout() {
		return $this->redirect($this->Auth->logout());
	}

	function admin_index() {
		$id = $this->Auth->user('id');
		$this->loadModel('Admin');
		if(!$this->Admin->isAdmin($id))
			throw new NotFoundException('404 Error - Page not found');

		$this->loadModel('Editor');
		$this->paginate = array(
			'order' => array('User.id' => 'desc'));
		$data = $this->paginate();
		foreach($data as $key => $value)
			$data[$key]['User']['isEditor'] = $this->Editor->isEditor($value['User']['id']);

		$this->set('users', $data);
	}

}
