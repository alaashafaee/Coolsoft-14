<?php
App::uses('AppController', 'Controller');
/**
 * Editors Controller
 *
 * @property Editor $Editor
 * @property PaginatorComponent $Paginator
 */
class EditorsController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

	function admin_delete() {
		$id = $this->Auth->user('id');
		$this->loadModel('Admin');
		if(!$this->Admin->isAdmin($id))
			throw new NotFoundException('404 Error - Page not found');

		$this->Editor->delete($this->request->query('uid'));

		return $this->redirect(array('controller' => 'users', 'action' => 'index'));
	}

	function admin_create() {
		$id = $this->Auth->user('id');
		$this->loadModel('Admin');
		if(!$this->Admin->isAdmin($id))
			throw new NotFoundException('404 Error - Page not found');

		$Editor = array('userid' => $this->request->query('uid'));
		$this->Editor->save($Editor);

		return $this->redirect(array('controller' => 'users', 'action' => 'index'));
	}
}
