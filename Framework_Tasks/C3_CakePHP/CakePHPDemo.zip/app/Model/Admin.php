<?php
App::uses('AppModel', 'Model');
/**
 * Admin Model
 *
 */
class Admin extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'userid';

	public function isAdmin($id) {
		$adminID = array(
			'Admin.userid' => $id
			);
		return $this->hasAny($adminID);
	}

}
