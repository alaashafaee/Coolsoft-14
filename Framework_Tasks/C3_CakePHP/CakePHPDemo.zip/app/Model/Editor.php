<?php
App::uses('AppModel', 'Model');
/**
 * Editor Model
 *
 * @property Post $Post
 */
class Editor extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'userid';


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * hasMany associations
 *
 * @var array
 */
	public $hasMany = array(
		'Post' => array(
			'className' => 'Post',
			'foreignKey' => 'userid',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

	public function isEditor($id) {
		$editorID = array(
			'Editor.userid' => $id
			);
		return $this->hasAny($editorID);
	}

}
