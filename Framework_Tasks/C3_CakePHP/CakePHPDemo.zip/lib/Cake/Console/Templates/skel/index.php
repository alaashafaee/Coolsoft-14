<?php
/**
 *
 *
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app
 * @since         CakePHP(tm) v 0.10.0.1076
 */

require 'webroot' . DIRECTORY_SEPARATOR . 'index.php';
